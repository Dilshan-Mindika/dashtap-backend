package com.dashtap.DASHTAP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashtapApplicationTests {

	@Test
	void contextLoads() {
	}

}
