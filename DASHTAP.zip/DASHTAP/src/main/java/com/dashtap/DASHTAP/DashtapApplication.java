package com.dashtap.DASHTAP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DashtapApplication {

	public static void main(String[] args) {
		SpringApplication.run(DashtapApplication.class, args);
	}

}
